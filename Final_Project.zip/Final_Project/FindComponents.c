//-------------------------------------------------------------
// Tyler Soriano 
// PA5
// FindComponents.c
//-------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "Graph.h"

int main(int argc, char* argv[])
{
	FILE* in_file  = fopen(argv[1], "r");
	FILE* out_file = fopen(argv[2], "w");

	if(in_file == NULL)
		exit(EXIT_FAILURE);

	int n, x, y;

	fscanf(in_file, "%d\n", &n);
	fscanf(in_file, "%d %d", &x, &y);

	Graph T = newGraph(n);

	while (x != 0 && y != 0)
	{
		addArc(T, x, y);
		fscanf(in_file, "%d %d", &x, &y);
	}
	
	fprintf(out_file, "Adjacency list representation of G: \n");
	printGraph(out_file, T);
	fprintf(out_file, "\n");

	List S = newList();

	for(int i = 1; i < n + 1; i++)
		append(S, i);


	DFS(T, S);

	//printList(out_file, S);

	//fprintf(out_file, "\n");

	//List TS = newList();

	/*moveFront(S);

	for(int i = 1; i < n + 1; i++)
	{
		append(TS, get(S));
		moveNext(S);
	}*/

	//printList(out_file, TS);

	//fprintf(out_file, "\n");

	Graph TT = transpose(T);

	DFS(TT, S);

	//printList(out_file, TS);

	//---------------------------------

	int c_count = 0;

	//printf("before\n");

	for(int j = 1; j <= getOrder(TT); j++)
	{
		if (getParent(TT, j) == NIL)
			c_count++;
	}

	//printf("after\n");

	//c_count++;
	fprintf(out_file, "\n");
	fprintf(out_file, "G contains %d strongly connected components: \n", c_count);

	/*List componentList = newList();

	moveFront(TS);

	for(int i = 1; i < n + 1; i++)
	{
		append(componentList, get(TS));
		moveNext(TS);
	}*/

	//printList(out_file, componentList);
	moveBack(S);

	List temp = newList();

	for(int i = 0; i < c_count; i++)
	{
		fprintf(out_file, "Component %d: ", i + 1);

		while(getParent(TT, get(S)) != NIL)
		{
			prepend(temp, get(S));
			movePrev(S);
		}

		prepend(temp, get(S));
		movePrev(S);

		printList(out_file, temp);
		fprintf(out_file, "\n");

		//clear(temp);

		freeList(&temp);
		temp = newList();
	}

	//printf("after2\n");
	
	//freeList(&temp);
	//freeList(&componentList);
	freeList(&S);
	//freeList(&TS);
	freeGraph(&T);
	freeGraph(&TT);
	fclose(in_file);
	fclose(out_file);

	return (0);
}




