//-------------------------------------------------------------
// Tyler Soriano 
// PA5
// GraphTest.c
//-------------------------------------------------------------
#include<stdio.h>
#include<stdlib.h>
#include"Graph.h"

int main(int argc, char* argv[])
{
	//Graph A = newGraph(6);

	int n = 35;

	Graph G = newGraph(n);

	//addEdge(G, 1, 8)
	//addEdge(G, 2, 9)
	//addEdge(G, 3, 10)

   	for(int i=1; i< n; i++){
      if( i%7!=0 ) addEdge(G, i, i+1);
	  if( i<=28  ) addArc(G, i, i+7);
   	}

   	printGraph(stdout, G);

   	printf("\n---------------------------------------\n");

	printGraph(stdout, transpose(G));
	
}