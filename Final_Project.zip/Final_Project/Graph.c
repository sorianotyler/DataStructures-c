//-------------------------------------------------------------
// Tyler Soriano 
// PA5
// Graph.c
//-------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include "Graph.h"


int time;

//Private helper methods
void visit(Graph G, List S, int x);

/*** Constructors-Destructors ***/
typedef struct GraphObj
{ 
	int order;					// counts the number of vertices  
	int size;
	int *color;					// the array of numbers - holds the number associated with the color for each edge 
	int *discover;				// the array of numbers - holds the number for each parent for each vertice 
	int *finish;				// the array of numbers - holds the number for the distance from the source
	int *parent;				// the array of numbers - holds the number for each parent for each vertice 	
	List adj[];					// the array of lists 
} GraphObj;

/* Constructors-Destructors */
Graph newGraph(int n)
{
	//Graph x = malloc( sizeof(GraphObj()) + sizeof(List[n+1]) + (3 * sizeof(int[n+1])) ); // allocate for all lists and arrays
	Graph x = malloc(sizeof(GraphObj) + sizeof(List[n + 1]));
 
	x->order = n + 1;
	x->size = 0;
	x->color = malloc(sizeof(int) * (n + 1));
	x->discover = malloc(sizeof(int) * (n + 1));
	x->finish = malloc(sizeof(int) * (n + 1));
	x->parent = malloc(sizeof(int) * (n + 1));
	
	for (int i = 1; i <= n; i++)
	{
		x->adj[i] = newList();
		x->color[i] = WHITE;
		x->discover[i] = UNDEF; 
		x->finish[i] = UNDEF;
		x->parent[i] = NIL;
	}

	return x;
}

void freeGraph(Graph* pG)
{
	if (pG != NULL && *pG != NULL)
	{
		if (getOrder(*pG) > 0)
		{
			for(int i = 1; i <= getOrder(*pG); i++)
				freeList(&((*pG)->adj[i]));
		}

		free((*pG)->color);
		free((*pG)->discover);
		free((*pG)->finish);
		free((*pG)->parent);
		free(*pG);
		*pG = NULL;
	}

	return;
}

int getSize(Graph G) 
{
	if (G == NULL)
		return NIL;

	return G->size;
}

/* Access functions */
/*** Access functions ***/
int getOrder(Graph G)
{
	if (G == NULL)
		return NIL;

	return G->order - 1;
}

int getParent(Graph G, int u) /* Pre: 1<=u<=n=getOrder(G) */
{
	if (G == NULL)
		return NIL;
	
	if ((u >= 1 && u <= getOrder(G)))
		return G->parent[u];
	else
		return NIL;
} 

int getDiscover(Graph G, int u) /* Pre: 1<=u<=n=getOrder(G) */ 
{
	if (G == NULL)
		return NIL;

	if ((u >= 1 && u <= getOrder(G)))
		return G->discover[u];
	else
		return NIL;

}

int getFinish(Graph G, int u) /* Pre: 1<=u<=n=getOrder(G) */
{
	if (G == NULL)
		return NIL;
	if (u < 1 || u > getOrder(G))
		return NIL;

	return G->finish[u];
}

/* Manipulation procedures */
void addEdge(Graph G, int u, int v) /* Pre: 1<=u<=n, 1<=v<=n */
{
	if (u > getOrder(G) || u < 1 )
		return;

	if (v > getOrder(G) || v < 1 )
		return;


	/*

	-- Add u to list v and v to list u IN SORTED ORDER
	

	2: [3], 4, 5,
	3:
	4: 2 
	
	*/

	addArc(G, u, v);
	addArc(G, v, u);

	G->size--;
	//Instead of reusing code, just call addArc() with parameters switched around
	
	/*List curr = G->adj[u];
	moveFront(curr);

	if(index(curr) == -1)
		append(curr, v);
	else if(v < get(curr))
		prepend(curr, v);
	else
	{
		while(index(curr) != -1 && get(curr) < v)
			moveNext(curr);

		if(index(curr) == -1)
			append(curr, v);
		else
			insertAfter(curr, v);
	}

	curr = G->adj[v];
	moveFront(curr);

	if(index(curr) == -1)
		append(curr, u);
	else if(u < get(curr))
		prepend(curr, u);
	else
	{
		while(index(curr) != -1 && get(curr) < u)
			moveNext(curr);

		if(index(curr) == -1)
			append(curr, u);
		else
			insertAfter(curr, u);
	}*/

}

void addArc(Graph G, int u, int v)/* Pre: 1<=u<=n, 1<=v<=n */
{
	List curr = G->adj[u];
	moveFront(curr);

	if(index(curr) == -1)
		append(curr, v);
	else if(v < get(curr))
		prepend(curr, v);
	else
	{
		while(index(curr) != -1 && get(curr) < v)
			moveNext(curr);

		if(index(curr) == -1)
			append(curr, v);
		else
			insertAfter(curr, v);
	}
	G->size++;
}

void DFS(Graph G, List S) /* Pre: length(S)==getOrder(G) */
{
	if(length(S) != getOrder(G))
		return;

	//printf("%d", 0);

	int x;

	for (x = 1; x < G->order; x++)
	{
		G->color[x] = WHITE;
		G->parent[x] = NIL;
	}

	time = 0;

	moveFront(S);

	while(index(S) != -1)
	{
		int z = get(S);

		//printf("%d", z);

		if (G->color[z] == WHITE)
			visit(G, S, z);

		moveNext(S);
	}

	//Now we know our list is double in length
	//Cut it in half

	for(int i = 1; i < G->order; i++)
		deleteBack(S);

	
	/*
	for (x = 1; x < G->order; x++)
	{
		if (G->color[x] == WHITE)
			visit(G, x);
	}*/
}

void visit(Graph G, List S, int x)
{
	G->discover[x] = (++time);
	G->color[x] = GRAY;

	List curr = G->adj[x]; 
	moveFront(curr);

	while (index(curr) != -1)
	{
		int curr_val = get(curr);

		if (G->color[curr_val] == WHITE)
		{
			G->parent[curr_val] = x;
			visit(G, S, curr_val);
		}

		moveNext(curr);
	}
	
	G->color[x] = BLACK;
	G->finish[x] = (++time);
	//printf("%d", x);
	prepend(S, x);
}

/* Other Functions */
Graph transpose(Graph G)
{
	Graph t = newGraph(G->order - 1);

	for(int i = 1; i < G->order; i++)
	{
		/*
		moveFront(G->adj[i]);

		while(index(G->adj[i]) != -1)
		{
			...
			moveNext(G->adj[i])
		}
		*/
		for(moveFront(G->adj[i]); index(G->adj[i]) != -1; moveNext(G->adj[i]))
			addArc(t, get(G->adj[i]), i);
	}

	return t;



}


Graph copyGraph(Graph G)
{
	Graph x = newGraph(G->order - 1);

	for(int i = 1; i < G->order; i++)
	{
		x->adj[i] = copyList(G->adj[i]);
		x->color[i] = G->color[i];
		x->discover[i] = G->discover[i];
		x->finish[i] = G->finish[i];
		x->parent[i] = G->parent[i];
	}

	return x;
}

void printGraph(FILE* out , Graph G)
{
	for(int i = 1; i < G->order; i++)
	{
		fprintf(out, "%d: ", i);
		printList(out, G->adj[i]);
		fprintf(out, "\n");
	}
}




