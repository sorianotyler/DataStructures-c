#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "List.h"

extern int strcmp(const char*, const char*);
extern char* strdup(const char *str1);


int main(int argc, char* argv[])
{
	FILE* in_file  = fopen(argv[1], "r");
	FILE* out_file = fopen(argv[2], "w");

	if(in_file == NULL)
		exit(EXIT_FAILURE);

	int lineCount = 0;

	while(1)
	{
		if(feof(in_file))
			break;

		if(fgetc(in_file) == '\n')
			lineCount++;
	}

	rewind(in_file);

	char* lines[lineCount];

	char buffer[100];

	int i = 0;
	//size_t len = 0;

	while(fgets(buffer, 100, in_file) != NULL)
	{
		lines[i] = strdup(buffer); //Remember to free all calls

		i++;
	}

	//insertion sort

	char* key;


	List s = newList();
	append(s, 0);
	moveBack(s);

	for(int x = 1; x < lineCount; x++)
	{
		key = lines[index(s) + 1];

		while(index(s) >= 0 && strcmp(key, lines[get(s)]) < 0)
			movePrev(s);

		if(index(s) >= 0)
			insertAfter(s, x);
		else
			prepend(s, x);

		moveBack(s);
	}

	moveFront(s);

	while(index(s) != -1)
	{
		fprintf(out_file, "%s", lines[get(s)]);
		moveNext(s);
	}


	for(int j = 0; j < lineCount; j++)
	{
		free(lines[j]);
	}

	freeList(&s);

	fclose(in_file);
	fclose(out_file);

	return 0;
}