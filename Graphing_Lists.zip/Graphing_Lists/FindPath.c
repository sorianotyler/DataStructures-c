//-------------------------------------------------------------
// Tyler Soriano 
// PA4
// FindPath.c
//-------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "Graph.h"

int main(int argc, char* argv[])
{
	FILE* in_file  = fopen(argv[1], "r");
	FILE* out_file = fopen(argv[2], "w");

	if(in_file == NULL)
		exit(EXIT_FAILURE);

	int i = 0;
	int n;
	int x, y;
	fscanf(in_file, "%d ", &n);
	fscanf(in_file, "%d, %d", &x, &y);

	Graph T = newGraph(n);

	while (x != 0 && y != 0)
	{
		fscanf(in_file, "%d, %d", &x, &y);
		
		if(T->adj[x] != NULL)
		{
			moveFront(T->adj[x]);

			for (i = 0; i < length(T->adj[x]); i++)
			{	
				if( (((ListObj*)T->adj[x])->next) > y )
				{
					moveNext(T->adj[x]);
					append(T->adj[x], y);
				}
				else if( (((ListObj*)T->adj[x])->next) == NULL )
				{
					append(T->adj[x], y);	
				}
				else
					moveNext(T->adj[x]);
			}
		}
		else
			append(T->adj[x], y);

	}

	printGraph(out_file, T);
   	fprintf(out_file, "\n");

   	int u, v;
   	List m = newList(); 
   	fscanf(in_file, "%d, %d", &u, &v);

   	while (u != 0 && v != 0)
   	{
   		BFS(T, u);
   		int d = getDist(T, v);
   		
   		if (d == INF)
   			fprintf(out_file, "The distance from %d to %d is infinity", u, v);

   		else
   			fprintf(out_file, "The distance from %d to %d is %d", u, v, d);
   		
   		fprintf(out, "\n");
   		getPath(m, T, v);
   		
   		if(m == NULL)
   			fprintf(out_file, "No %d-%d path exists", u, v);
   		
   		else
   		{
   			fprintf(out_file, "A shortest %d-%d path is: ", u, v);
   			printList(out_file, m);
   		}
   		
   		fprintf(out_file, "\n");
   		fprintf(out_file, "\n");

   		fscanf(in_file, "%d, %d", &u, &v);
   	}

}