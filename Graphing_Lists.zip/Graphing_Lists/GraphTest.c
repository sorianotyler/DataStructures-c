//-------------------------------------------------------------
// Tyler Soriano 
// PA4
// GraphTest.c
//-------------------------------------------------------------
#include<stdio.h>
#include<stdlib.h>
#include"Graph.h"

int main(int argc, char* argv[])
{
	Graph A = newGraph(6);
	printGraph(stdout, A);
	
}