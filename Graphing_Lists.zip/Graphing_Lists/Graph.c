//-------------------------------------------------------------
// Tyler Soriano 
// PA4
// Graph.c
//-------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include "Graph.h"

#define  INF -1
#define  NIL -2
#define  WHITE 1
#define  GRAY 2
#define  BLACK 3

/*** Constructors-Destructors ***/
typedef struct GraphObj
{ 
	int order;					// counts the number of vertices  
	int size;					// count of # of edges 
	int source;					// source used by BFS
	int *color;					// the array of numbers - holds the number associated with the color for each edge 
	int *parent;				// the array of numbers - holds the number for each parent for each vertice 
	int *distance;				// the array of numbers - holds the number for the distance from the source
	List adj[];					// the array of lists 
} GraphObj;

Graph newGraph(int n)
{
	//Graph x = malloc( sizeof(GraphObj()) + sizeof(List[n+1]) + (3 * sizeof(int[n+1])) ); // allocate for all lists and arrays
	Graph x = malloc(sizeof(GraphObj) + sizeof(List[n + 1]));
 
	x->order = n + 1;
	x->size = 0;
	x->source = NIL;
	x->color = malloc(sizeof(int) * (n + 1));
	x->parent = malloc(sizeof(int) * (n + 1));
	x->distance = malloc(sizeof(int) * (n + 1));
	
	for (int i = 1; i <= n; i++)
	{
		x->adj[i] = newList();
		x->color[i] = WHITE;
		x->parent[i] = NIL; 
		x->distance[i] = INF;
	}

	return x;
}

void freeGraph(Graph* pG)
{
	if (pG != NULL && *pG != NULL)
	{
		if (getSize(*pG) > 0)
		{
			for(int i = 1; i <= (*pG)->order; i++)
				freeList(&((*pG)->adj[i]));
		}

		free((*pG)->color);
		free((*pG)->distance);
		free((*pG)->parent);
		free(*pG);
		*pG = NULL;
	}

	return;
}

/*** Access functions ***/
int getOrder(Graph G)
{
	if (G == NULL)
		return NIL;

	return G->order;
}

int getSize(Graph G)
{
	if (G == NULL)
		return NIL;

	return G->size;
}

int getSource(Graph G)
{
	if (G == NULL)
		return NIL;

	return G->source;
}

int getParent(Graph G, int u)
{
	if (G == NULL)
		return NIL;
	
	if (u > getOrder(G) || u < 1 )
		return NIL;

	return G->parent[u];
}

int getDist(Graph G, int u)
{
	if (G == NULL)
		return NIL;

	if (u > getOrder(G) || u < 1 )
		return NIL;

	return G->distance[u];
}

void getPath(List L, Graph G, int u)
{
	int x = getSource(G);

	if (x == NIL)
		return;

	if (u > x || u < 1 )
		return;

	if(u == x)
		append(L, u);

	else if( u != x )
	{
		append(L, u);
		int t = getParent(G, u);
		
		while(t != NIL && t != x )
		{
			append(L, t);
			t = getParent(G, t);
		}
		
		if (t == NIL)
			append(L, NIL);
		else 
			append(L, t);
	}

}
/*** Manipulation procedures ***/

void makeNull(Graph G)
{
	if(G == NULL)
		return;

	for(int x = 1; x <= G->order; x++)
	{
		G->color[x] = WHITE;
		G->distance[x] = INF;
		G->parent[x] = NIL;
	}

	G->order = 0;
	G->size = 0;
	G->source = NIL;

}

void addEdge(Graph G, int u, int v)
{
	if (u > getOrder(G) || u < 1 )
		return;

	if (v > getOrder(G) || v < 1 )
		return;
	
	int i, j;
	movefront(G->adj[u]);

	if (((ListObj*)G->adj[u])->next > v)
	{
		moveNext(G->adj[u]);
		append(G->adj[u], v);
	}
	else
		moveNext(G->adj[u]);

	
	movefront(G->adj[v]);
	
	if (((ListObj*)G->adj[v])->next > u)
	{
		moveNext(G->adj[v]);
		append(G->adj[v], u);
	}
	else
		moveNext(G->adj[v]);

}

void addArc(Graph G, int u, int v)
{
	if (G == NULL)
		return;

	if (v > getOrder(G) || v < 1 )
		return;

	if (u > getOrder(G) || u < 1 )
		return;

	int i;
	movefront(G->adj[u]);

	if((G->adj[u])->next > v)
	{
		moveNext(G->adj[u]);
		append(G->adj[u], v);
	}
	else
		moveNext(G->adj[u]);


}

void BFS(Graph G, int s)
{
	G->source = s;

	if (G == NULL)
		return;

	if (s > getOrder(G) || s < 1 )
		return;

	int x;

	for(x = 1; x <= G->order - s; x++)
	{
		G->color[x] = WHITE;
		G->distance[x] = INF;
		G->parent[x] = NIL;
	}
	G->color[s] = GRAY;
	G->distance[s] = 0;
	G->parent[x] = NIL;
	List Q = newList();
	append(Q,s);
	while(Q != 0)
	{
		x = back(Q);
		deleteBack(Q);
		for(int y = 1; y <= length(G->adj[x]); y++)
		{
			if(G->color[y] == WHITE)
			{
				G->color[y] = GRAY;
				G->distance[y] = ( G->distance[x] + 1 );
				G->parent[y] = x;
				append(Q, y);
			}
		}
		G->color[x] = BLACK;
	}
	freeList(&Q); //If Q is not being used anywhere else in the program
}
/*** Other operations ***/
void printGraph(FILE* out, Graph G)
{
	for(int i = 1; i < G->order; i++)
	{
		fprintf(out, "%d: ", i);
		printList(out, G->adj[i]);
		fprintf(out, "\n");
	}
}



