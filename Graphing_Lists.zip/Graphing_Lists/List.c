//--------------------------------------------------
// Tyler Soriano
// tsoriano@ucsc.edu
// pa4
// List.c
//--------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "List.h"

typedef struct NodeObj
{
	int item;				// data
	struct NodeObj* next;   // points to the next object
	struct NodeObj* last;	// points to the last object
} NodeObj;

// Declaration of NodeObj
typedef NodeObj* Node;

typedef struct ListObj
{
	Node head; //Pointer to first NodeObj in List
	Node tail; //last

	int numPairs;   		// number of pairs
	int cursor;			//pointer to current Node?
} ListObj;

Node newNode(int i)
{
	Node newN = malloc(sizeof(NodeObj)); 	// allocate memory

	newN->item = i;						// sets value to value

	newN->next = NULL;						// next is null
	newN->last = NULL;						// last is null

	return newN;							// returns the Node
}

// this function free the current node
void freeNode(Node* T)
{
	if (T != NULL && *T != NULL)
	{
		free(*T);
		*T = NULL;
	}
}

// newDictionary()
// constructor for the Dictionary type
List newList(void)
{
	List newList = malloc(sizeof(ListObj)); // allocate memory

	newList->numPairs = 0;								// everything is null
	newList->cursor = -1;

	newList->head = NULL;
	newList->tail = NULL;

	return newList;
}

// freeDictionary()
// destructor for the Dictionary type
void freeList(List* pL)
{
	if(pL != NULL && *pL != NULL)
	{
		if(length(*pL) > 0)
			clear(*pL); //Call clear()

		free(*pL);
		*pL = NULL;
	}
}

// length
// Returns the number of elements in
int length(List L){
	return L->numPairs;
}

// index
// Returns index of cursor if defined, -1 otherwise
int index(List L)
{
	return L->cursor;
}

// front
// Returns the front element of L -> length() > 0
int front(List L)
{

	return length(L) > 0 ? L->head->item : -1;

	//Same as above line

	/*if(length(L) > 0)
	{
		return L->head->data;
	}
	else
	{
		return -1;
	}*/

}

// back
// Returns the back element of L -> length() > 0
int back(List L)
{
	return length(L) > 0 ? L->tail->item : -1;
}

// get
// Returns the corsur element of L -> length() > 0 ; index() >= 0
int get(List L)
{
	if(length(L) > 0 && index(L) >= 0)
	{
		Node temp = L->head;
		int c = 0;

		while(temp->next != NULL && c < L->cursor)
		{
			temp = temp->next;
			c++;
		}

		return temp->item;
	}

	return -1;
}

// equals
// returns true, 1, if lists are the same
// returns false, 0, if otherwise
int equals(List A, List B)
{
	if( (A->numPairs != B->numPairs) )
		return 0;

	Node t1 = A->head;
	Node t2 = B->head;

	while(t1 != NULL && t2 != NULL)
	{
		if(t1->item != t2->item)
			return 0;

		t1 = t1->next;
		t2 = t2->next;
	}

	return 1;
}


// Manipulation functions-------------------------------------------------------
// Resets L to its original empty state.
void clear(List L)
{
	Node n = L->head;

	while(n != NULL)
	{
		Node temp = n->next;
		freeNode(&n);
		n = temp;

		L->numPairs--;
	}

	L->cursor = -1;
}

// moveFront
// If L is non-empty, sets cursor under the front element,
// otherwise does nothing.
void moveFront(List L)
{
	if(length(L) > 0)
		L->cursor = 0;
}

// moveBack
// If L is non-empty, sets cursor under the back element,
// otherwise does nothing.
void moveBack(List L)
{
	if(length(L) > 0)
		L->cursor = (L->numPairs) - 1;
}

// movePrev
// If cursor is defined and not at front, move cursor one
// step toward the front of L; if cursor is defined and at
// front, cursor becomes undefined; if cursor is undefined
// do nothing
void movePrev(List L)
{
	if(index(L) >= 0)
		L->cursor--;
}

// moveNext
// If cursor is defined and not at back, move cursor one
// step toward the back of L; if cursor is defined and at
// back, cursor becomes undefined; if cursor is undefined
// do nothing
void moveNext(List L)
{
	if(index(L) < (L->numPairs - 1))
		L->cursor++;
	else if(index(L) >= (L->numPairs - 1))
		L->cursor = -1;
}


// prepend
// Insert new element into L. If L is non-empty,
// insertion takes place before front element.
void prepend(List L, int data)
{
	Node n = newNode(data);

	//3498 33464 324 3674 354 4 435 [34]
	if(length(L) > 0)
	{
		n->next = L->head;
		(L->head)->last = n;
		L->head = n;

		if(index(L) >= 0)
			L->cursor++;
	}
	else if(length(L) == 0)
	{
		L->head = n;
		L->tail = n;
	}

	//Whenever we insert, increment numPairs
	L->numPairs++;
}

// append
// Insert new element into L. If L is non-empty,
// insertion takes place after back element.
void append(List L, int data)
{
	Node n = newNode(data);

	if(length(L) > 0)
	{
		n->last = L->tail;
		L->tail->next = n;
		L->tail = n;
	}
	else if(length(L) == 0)
	{
		L->head = n;
		L->tail = n;
	}

	//Whenever we insert, increment numPairs
	L->numPairs++;
}

// insertBefore
// Insert new element before cursor.
// Pre: length()>0, index()>=0
void insertBefore(List L, int data)
{
	//34 4 354 [3674]
	if(length(L) > 0 && index(L) >= 0)
	{
		if(index(L) == 0)
		{
			prepend(L, data);

			return;
		}

		Node t = L->head;

		Node newN = newNode(data);

		int i = 0;

		while(i < L->cursor)
		{
			t = t->next;
			i++;
		}

		//1 5 7
		//1 [5] 7


		(t->last)->next = newN;
		newN->last = t->last;
		t->last = newN;
		newN->next = t;

		L->numPairs++;

		if(index(L) >= 0)
			L->cursor++;
	}
}

// insertAfter
// Insert new element before cursor.
// Pre: length()>0, index()>=0
void insertAfter(List L, int data)
{
	if(length(L) > 0 && index(L) >= 0)
	{
		//If cursor is at end, append
		if(index(L) == length(L) - 1)
		{
			append(L, data);
			return;
		}

		Node t = L->head;

		Node newN = newNode(data);

		int i = 0;

		while(i < L->cursor)
		{
			t = t->next;
			i++;
		}


		(t->next)->last = newN;
		newN->next = t->next;
		t->next = newN;
		newN->last = t;

		L->numPairs++;
		//L->cursor++;
	}
}

// deletefront
// Delete the front element. Pre: length()>0
void deleteFront(List L)
{
	//2 43 65 [5]
	Node n = L->head;

	L->head = n->next;

	freeNode(&n);

	L->numPairs--;
	movePrev(L);
}

// deleteBack
// Delete the back element. Pre: length()>0
void deleteBack(List L)
{
	//[1] 8 2 43 65
	Node n = L->tail;

	L->tail = n->last;

	freeNode(&n);

	if(index(L) == (L->numPairs - 1))
		moveNext(L);

	L->numPairs--;
}

// delete
// Delete cursor element, making cursor undefined.
// Pre: length()>0, index()>=0
void delete(List L)
{
	if(length(L) > 0 && index(L) >= 0)
	{
		Node n = L->head;

		int i = 0;

		while(i < L->cursor)
		{
			n = n->next;
			i++;
		}

		if(i == 0) //Deleting head element
			L->head = n->next;
		else if(i == (L->numPairs - 1)) //Deleting last element
			L->tail = n->last;
		else //Deleting somewhere in between
		{
			(n->last)->next = n->next;
			(n->next)->last = n->last;
		}

		freeNode(&n);

		L->cursor = -1;

		L->numPairs--;
	}
}

// Other operations -----------------------------------------------------------

// printList
// Prints to the file pointed to by out, a
// string representation of L consisting
// of a space separated sequence of integers,
// with front on left.
void printList(FILE* out, List L)
{
	Node n = L->head;

	while(n != NULL)
	{
		fprintf(out, "%d ", n->item);
		n = n->next;
	}
}

// copyList
// Returns a new List representing the same integer
// sequence as L. The cursor in the new list is undefined,
// regardless of the state of the cursor in L. The state // of L is unchanged.
List copyList(List L)
{
	List newL = newList();

	Node p = L->head;

	while(p != NULL)
	{
		append(newL, p->item);

		p = p->next;
	}

	return newL;
}
