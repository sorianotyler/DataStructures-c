//-------------------------------------------------------------
// Tyler Soriano
// PA3
// BigInteger.C
//-------------------------------------------------------------

#include "BigInteger.h"
#include "List.h"
#include <math.h>
//#include <string.h>

extern char* strchr(const char *, int);
extern void *memset(void *ptr, int x, size_t n);

#define BASE 10
#define POWER 9

//Private helper methods
BigInteger unsign_add(BigInteger A, BigInteger B);
BigInteger unsign_sub(BigInteger A, BigInteger B);

// Exported type -------------------------------------------------------------
// BigInteger reference type
typedef struct BigIntegerObj
{
	List biginteger;
	int sign;

} BigIntegerObj;

// Constructors-Destructors ---------------------------------------------------

// newBigInteger()
// Returns a reference to a new BigInteger object in the zero state.
BigInteger newBigInteger()
{
	BigInteger x = malloc(sizeof(BigIntegerObj()));

	x->biginteger = newList();
	x->sign = 0;

	return x;
}

// freeBigInteger()
// Frees heap memory associated with *pN, sets *pN to NULL.
void freeBigInteger(BigInteger* pN)
{
	if (pN != NULL && *pN != NULL)
    {
        freeList(&(*pN)->biginteger);
        free(*pN);
        *pN = NULL;
    }
}

// Access functions -----------------------------------------------------------
// sign()
// Returns -1 if N is negative, 1 if N is positive, and 0 if N is in the zero // state.
int sign(BigInteger N)
{
	return N->sign;
}

// compare()
// Returns -1 if A<B, 1 if A>B, and 0 if A=B.
int compare(BigInteger A, BigInteger B)
{
    if(A->sign < B->sign)
        return -1;

    else if(A->sign > B->sign)
        return 1;

    else //they have equal signs
    {
        return compareL(A->biginteger, B->biginteger);
    }
}

//unsign_compares the 2 numbers witout the sign
// helps when doing the arithmatic
int unsign_compare(BigInteger A, BigInteger B)
{
    return compareL(A->biginteger, B->biginteger);
}

// equals()
// Return true (1) if A and B are equal, false (0) otherwise.
int equals(BigInteger A, BigInteger B)
{
	if(sign(A) != sign(B))
		return 0;

	/*moveFront(A->biginteger);  // move to the front of the list for A
	moveFront(B->biginteger);

	for(int j = 0; j < length(A->biginteger); j++)  // itterate through and get A and B values
	{
		long list_valA = get(A->biginteger);
		long list_valB = get(B->biginteger);

		if(list_valA != list_valB) // if values dont match then exit
			return 0;

		moveNext(A->biginteger); // move next for A and B
		moveNext(B->biginteger);
	}

	return 1; */

	return equalsL(A->biginteger, B->biginteger);
}

// Manipulation procedures ----------------------------------------------------
// makeZero()
// Re-sets N to the zero state.
void makeZero(BigInteger N)
{
	clear(N->biginteger);
	N->sign = 0;
}

// negate()
// Reverses the sign of N: positive <--> negative. Does nothing if N is in the // zero state.
void negate(BigInteger N)
{
	if(N->sign == 0)
		return;

	if(N->sign == 1)
		N->sign = -1;
	else if(N->sign == -1)
		N->sign = 1;
}

// BigInteger Arithmetic operations -----------------------------------------------

// stringToBigInteger()
// Returns a reference to a new BigInteger object representing the decimal integer
// represented in base 10 by the string s.
// Pre: s is a non-empty string containing only base ten digits {0,1,2,3,4,5,6,7,8,9}
// and an optional sign {+, -} prefix.
BigInteger stringToBigInteger(char* s)
{
    int sgn = 0;

    int s_len = sizeof(*s) / sizeof(char);

    if(s_len == 0)
        return NULL;

    BigInteger n = newBigInteger();

	n->sign = 1;

	if(s == "0")
		n->sign = 0;

    if(s[0] == '-')
	{
		n->sign = -1;
		sgn = 1;
	}
	else if(s[0] == '+')
		sgn = 1;

	char* offset = s + sgn;

	char num[POWER + 1];

	memset(num, '0', POWER);

	char* e = strchr(s, '\0') - 1;
	int c = POWER;
	num[c--] = '\0';

	char* x;

	//402779357'\0'

	//7402779357

	while(e >= offset)
	{
		num[c--] = *e;
		e--;

		if(c < 0)
		{
			c = POWER;
			//printf("%s\n", num);
			append(n->biginteger, strtol(num, &x, 10));

			//clear
			memset(num, '0', POWER);
			num[c--] = '\0';
		}

		//printf("%c\n", *e);
		/*
		if(c == 0)
		{
			num[--c] = *e;
			c = POWER;
			printf("%ld\n", strtol(num, &x, 10));
			//printf("%s\n", num);
			append(n->biginteger, strtol(num, &x, 10));

			//clear
			memset(num, '0', POWER);
			num[c] = '\0';
		}

		num[--c] = *e;
		e--;
		*/
	}

	long v = strtol(num, &x, 10);

	if(v != 0)
		append(n->biginteger, v);

    return n;
}
// copy()
// Returns a reference to a new BigInteger object in the same state as N .
BigInteger copy(BigInteger N)
{
	BigInteger T  = newBigInteger();

	T->sign = N->sign;

	T->biginteger = copyList(N->biginteger);

	return T;
}

// add()
// Places the sum of A and B in the existing BigInteger S, overwriting its
// current state: S = A + B
void add(BigInteger S, BigInteger A, BigInteger B)
{
	BigInteger temp = sum(A, B);

    makeZero(S);

    S->biginteger = copyList(temp->biginteger);
    S->sign = temp->sign;

    freeBigInteger(&temp);
}


// sum()
// Returns a reference to a new BigInteger object representing A + B.
BigInteger sum(BigInteger A, BigInteger B)
{
    if(A->sign == B->sign)
    {
		BigInteger t = unsign_add(A, B);
		t->sign = A->sign;

		return t;
    }
    else
    {
        if(compare(A, B) < 0) // A < B
        {
            if(unsign_compare(A, B) > 0) //unsigned A > unsigned B
            {
                BigInteger t = unsign_sub(A, B);
                t->sign = A->sign;

                return t;
            }
            else //unsigned B >= unsigned A
            {
                BigInteger t = unsign_sub(B, A);
                t->sign = B->sign;

                return t;
            }
        }
        else // B <= A
        {
            BigInteger t = unsign_sub(A, B);
            t->sign = A->sign;

            return t;
        }
    }
}

//PRIVATE HELPER FUNCTION
BigInteger unsign_add(BigInteger A, BigInteger B)
{
    BigInteger result = newBigInteger();
    result->sign = 1; // Unsigned
    int carry = 0;

    moveFront(A->biginteger);
    moveFront(B->biginteger);

    // Loop through BigInteger A
    while(index(A->biginteger) >= 0) {

        long cur_sum = 0;
        // If the index of BigInteger B
        // Is off the list before BigInteger A

        if(index(B->biginteger) < 0)
            cur_sum = get(A->biginteger) + carry;
        else
            cur_sum = get(A->biginteger) + get(B->biginteger) + carry;


        // Decrement the carry if its already > 0 before the next calculation
        // of pair sums
        if(carry > 0)
            carry--;

        // If the pair_Sum is >= 10^POWER --> BASE
        // Then increment the carry and change the pair sum accordingly
        // i.e. if 90 + 14 = 105 and powl(10, 2) = 100
        // then pair_Sum >= 10^POWER --> BASE therefore 105 - 100
        // --> 5 and then append that value to the Result BigInteger
        if(cur_sum >= powl(BASE, POWER))
        {
            carry++;
            cur_sum = cur_sum % (int)powl(BASE, POWER);
        }

        append(result->biginteger, cur_sum);

        moveNext(A->biginteger);
        moveNext(B->biginteger);

    }

    // Our previous loop only loops until BigInteger A falls off the list
    // So we check if there are still remaining values in B
    while(index(B->biginteger) >= 0)
    {
        // add the previous carry, and append the values of B to
        // the result BigInteger
        append(result->biginteger, get(B->biginteger) + carry);

        // decrement it after
        if(carry > 0)
            carry--;

        moveNext(B->biginteger);
    }

    // Case: Extra Carry
    // Append the extra carry within the range 1 to the BASE^POWER - 1
    if(carry > 0)
        append(result->biginteger, powl(BASE, POWER - 1));

    return result;
}

BigInteger unsign_sub(BigInteger A, BigInteger B)
{
    BigInteger result = newBigInteger();
    result->sign = 1; // Unsigned
    int borrow = 0;

    moveFront(A->biginteger);
    moveFront(B->biginteger);

    while(index(A->biginteger) >= 0)
    {
        long curr_diff = 0;

        if(index(B->biginteger) < 0)
        {
            curr_diff = get(A->biginteger) - borrow;
            borrow = 0;
        }
        else
        {
            long temp_val = get(A->biginteger) - borrow;

            if(temp_val < get(B->biginteger))
            {
                temp_val += powl(BASE, POWER);
                curr_diff = temp_val - get(B->biginteger);
                borrow = 1;
            }
            else
            {
                curr_diff = temp_val - get(B->biginteger);
                borrow = 0;
            }
        }

        append(result->biginteger, curr_diff);

        moveNext(A->biginteger);
        moveNext(B->biginteger);
    }

    return result;
}

// subtract()
// Places the difference of A and B in the existing BigInteger D, overwriting
//itscurrentstate: D=A-B
void subtract(BigInteger D, BigInteger A, BigInteger B)
{
    BigInteger temp = diff(A, B);

    makeZero(D);

    D->biginteger = copyList(temp->biginteger);
    D->sign = temp->sign;

    freeBigInteger(&temp);
}

// diff()
// Returns a reference to a new BigInteger object representing A - B.
BigInteger diff(BigInteger A, BigInteger B)
{
	// need for the case were they are same sign
	// different signs
	// different signs A larger
	// different signs A smaller
	// Same sign A larger
	// same sign A smaller

	if(A->sign == B->sign)
    {
        if(A->sign == -1)
        {
			if(unsign_compare(A, B) > 0) //unsigned A > unsigned B
			{
				BigInteger T = unsign_sub(A, B);
				T->sign = -1;
				return T;
			}
			if(unsign_compare(A, B) < 0) //unsigned A < unsigned B
			{
				BigInteger T = unsign_sub(B, A);
				T->sign = 1;
				return T;
			}
			else
			{
				return stringToBigInteger("0");
			}
        }
        else if(A->sign == 1)
        {
        	if(unsign_compare(A, B) > 0) //unsigned A > unsigned B
        		return unsign_sub(A, B);

        	if(unsign_compare(A, B) < 0) //unsigned A < unsigned B
        	{
        		BigInteger T = unsign_sub(B, A);
        		T->sign = -1;
        		return T;
        	}
			else
			{
				return stringToBigInteger("0");
			}
        }
		else
		{
			return NULL;
		}
    }
    else
    {
        if(compare(A, B) < 0) // A < B (A is negative)
        {
			BigInteger t = unsign_add(B, A);
			t->sign = -1;

			return t;
        }
        else // B <= A (B is negative)
        {
			BigInteger t = unsign_add(B, A);
			t->sign = 1;

			return t;
        }
    }
}

// multiply()
// Places the product of A and B in the existing BigInteger P, overwriting // its current state: P = A*B
void multiply(BigInteger P, BigInteger A, BigInteger B)
{
	BigInteger temp = prod(A, B);

    makeZero(P);

    P->biginteger = copyList(temp->biginteger);
    P->sign = temp->sign;

    freeBigInteger(&temp);
}

// prod()
// Returns a reference to a new BigInteger object representing A*B BigInteger
BigInteger prod(BigInteger A, BigInteger B)
{
	BigInteger product = stringToBigInteger("0");

    long power = 0;

    moveFront(B->biginteger);

    while(index(B->biginteger) >= 0) //142334
    {
        long x = get(B->biginteger);

        List partial = newList();

        for(int i = 0; i < power; i++)
            append(partial, 0);

        moveFront(A->biginteger);

        long carry = 0;

        while(index(A->biginteger) >= 0) //7007
        {
            long y = get(A->biginteger);

            long z = x * y + carry;

            carry = z / (int)powl(BASE, POWER);

            z = z % (int)powl(BASE, POWER);

            append(partial, z);

            moveNext(A->biginteger);
        }

        if(carry)
            append(partial, carry);

        BigInteger t = newBigInteger();
        t->sign = 1;
        t->biginteger = partial;

        add(product, product, t);

        freeBigInteger(&t);

        moveNext(B->biginteger);

        power += 1;

    }

    product->sign = A->sign * B->sign;

    return product;
}


// Other operations -----------------------------------------------------------
// printBigInteger()
// Prints a base 10 string representation of N to filestream out.
void printBigInteger(FILE* out, BigInteger N)
{
    if(N->sign < 0)
        fprintf(out, "-");

    printListFormatted(out, N->biginteger, POWER);
}
