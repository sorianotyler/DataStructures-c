//-------------------------------------------------------------
// Tyler Soriano
// PA3
// Arithmetic.c
//-------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include "BigInteger.h"

int main(int argc, char const *argv[])
{
	FILE* in_file  = fopen(argv[1], "r");
	FILE* out_file = fopen(argv[2], "w");

	if(in_file == NULL)
		exit(EXIT_FAILURE);

    int len_a;
    int len_b;

    fscanf(in_file, "%d\n", &len_a);

    char a_str[len_a + 2]; //account for sign and null terminator

    fgets(a_str, len_a + 2, in_file);

    for(int i = 0; i < len_a + 2; i++)
        if(a_str[i] == '\n')
            a_str[i] = '\0';

    fscanf(in_file, "%d\n", &len_b);

    char b_str[len_b + 2]; //account for sign and null terminator

    fgets(b_str, len_b + 2, in_file);

    for(int i = 0; i < len_b + 2; i++)
    {
        if(b_str[i] == '\n')
            b_str[i] = '\0';
    }

	BigInteger A = stringToBigInteger(a_str);
	BigInteger B = stringToBigInteger(b_str);

	//A
	printBigInteger(out_file, A);
	fprintf(out_file, "\n");

	//B
	printBigInteger(out_file, B);
	fprintf(out_file, "\n");

	// A + B
	BigInteger C = sum(A, B);
	printBigInteger(out_file, C);
	fprintf(out_file, "\n");

	// A - B
	BigInteger D = diff(A, B);
	printBigInteger(out_file, D);
	fprintf(out_file, "\n");

	// A - A
	BigInteger E = diff(A, A);
	printBigInteger(out_file, E);
	fprintf(out_file, "\n");

	// 3A - 2B
	BigInteger F = prod(stringToBigInteger("3"), A);
	BigInteger G = prod(stringToBigInteger("2"), B);
	BigInteger I = diff(F, G);
	printBigInteger(out_file, I);
	fprintf(out_file, "\n");

	// AB
	BigInteger J = prod(A, B);
	printBigInteger(out_file, J);
	fprintf(out_file, "\n");

	// A^2
    BigInteger CPA_1 = copy(A);
	BigInteger K = prod(A, CPA_1);
	printBigInteger(out_file, K);
	fprintf(out_file, "\n");

	// B^2
    BigInteger CPB_1 = copy(B);
	BigInteger L = prod(B, CPB_1);
	printBigInteger(out_file, L);
	fprintf(out_file, "\n");

    //9A^4 + 16B^5
    BigInteger CPA_2 = copy(A);
	BigInteger M = newBigInteger();
    multiply(M, A, CPA_2); //M = A^2
    multiply(M, M, prod(A, CPA_2)); //A^4
	BigInteger O = prod(stringToBigInteger("9"), M); //9A^4

    BigInteger CPB_2 = copy(B);
	BigInteger M_1 = newBigInteger();
    multiply(M_1, B, CPB_2); //M_1 = B^2
    multiply(M_1, M_1, prod(copy(M_1), CPB_2)); //M_1 = B^5

	BigInteger P = prod(stringToBigInteger("16"), M_1); //16B^5

	printBigInteger(out_file, sum(O, P));
	fprintf(out_file, "\n");

	freeBigInteger(&A);
	freeBigInteger(&B);
	freeBigInteger(&C);
	freeBigInteger(&D);	
	freeBigInteger(&E);
	freeBigInteger(&F);
	freeBigInteger(&G);
	freeBigInteger(&I);
	freeBigInteger(&J);
	freeBigInteger(&CPA_1);
	freeBigInteger(&K);
	freeBigInteger(&CPB_1);
	freeBigInteger(&L);
	freeBigInteger(&CPA_2);
	freeBigInteger(&M);
	freeBigInteger(&O);
	freeBigInteger(&CPB_2);
	freeBigInteger(&M_1);
	freeBigInteger(&P);
   	
   	fclose(in_file);
	fclose(out_file);

	return 0;
}
