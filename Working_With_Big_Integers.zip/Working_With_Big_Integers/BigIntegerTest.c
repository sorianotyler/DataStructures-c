
#include "BigInteger.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main(int argc, char const *argv[])
{

    BigInteger A = stringToBigInteger("9163574346363325007361058");
    //BigInteger A = stringToBigInteger("642");
                                     //+001100001010
    BigInteger B = stringToBigInteger("+4597814412658653960738664");
    //BigInteger B = stringToBigInteger("36");
                                     //309172304712304872131203847120384
    BigInteger C = stringToBigInteger("0");

    printBigInteger(stdout, A);
    printBigInteger(stdout, B);
    printBigInteger(stdout, C);

    printBigInteger(stdout, sum(A, B));
    printBigInteger(stdout, diff(A, B));
    printBigInteger(stdout, prod(A, C));

    //add(C, A, A);
    //add(C, C, A);

    //printBigInteger(stdout, C);


    //diff(A, B);

    return 0;
}
