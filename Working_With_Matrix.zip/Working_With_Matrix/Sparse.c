//----------------------------------------------------------------------
// Tyler Soriano 
// tsoriano@ucsc.edu
// Sparse.c
//----------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "Matrix.h"

int main(int argc, char* argv[])
{
	FILE* in_file  = fopen(argv[1], "r");
	FILE* out_file = fopen(argv[2], "w");

	if(in_file == NULL)
		exit(EXIT_FAILURE);

	int n, a, b;

	fscanf(in_file, "%d %d %d", &n, &a, &b);

	Matrix A = newMatrix(n);

	Matrix B = newMatrix(n);

	int row, col;
	double val;

	for(int i = 0; i < a; i++)
	{
		fscanf(in_file, "%d %d %lf", &row, &col, &val);
		changeEntry(A, row, col, val);
	}

	for(int j = 0; j < b; j++)
	{
		fscanf(in_file, "%d %d %lf", &row, &col, &val);
		changeEntry(B, row, col, val);
	}

	fprintf(out_file, "A has %d non-zero entries:\n", NNZ(A));
   	printMatrix(out_file, A);
   	fprintf(out_file, "\n");

   	fprintf(out_file, "B has %d non-zero entries:\n", NNZ(B));
   	printMatrix(out_file, B);
   	fprintf(out_file, "\n");

   	Matrix SM = scalarMult(1.5, A);

   	fprintf(out_file, "(%.1f)*A = \n", 1.5);
   	printMatrix(out_file, SM);
   	fprintf(out_file, "\n");

   	Matrix S = sum(A, B);

   	fprintf(out_file, "A+B = \n");
   	printMatrix(out_file, S);
   	fprintf(out_file, "\n");

   	Matrix copyA = copy(A);
   	Matrix copyB = copy(B);

   	Matrix SA = sum(A, copyA);

   	fprintf(out_file, "A+A = \n");
   	printMatrix(out_file, SA);
   	fprintf(out_file, "\n");

   	Matrix D = diff(B, A);
   	
   	fprintf(out_file, "B-A = \n");
   	printMatrix(out_file, D);
   	fprintf(out_file, "\n");

   	Matrix DA = diff(A, copyA);

   	fprintf(out_file, "A-A = \n");
   	printMatrix(out_file, DA);
   	fprintf(out_file, "\n");

   	Matrix TP = transpose(A);

	fprintf(out_file, "Transpose(A) = \n");
   	printMatrix(out_file, TP);
   	fprintf(out_file, "\n");

   	Matrix M = product(A, B);

   	fprintf(out_file, "A*B = \n");
   	printMatrix(out_file, M);
   	fprintf(out_file, "\n");

   	Matrix MB = product(B, copyB);

   	fprintf(out_file, "B*B = \n");
   	printMatrix(out_file, MB);
   	fprintf(out_file, "\n");

   	freeMatrix(&A);
   	freeMatrix(&B);
   	freeMatrix(&SM);
   	freeMatrix(&S);
   	freeMatrix(&SA);
   	freeMatrix(&D);
   	freeMatrix(&DA);
   	freeMatrix(&M);
   	freeMatrix(&MB);
   	freeMatrix(&copyA);
   	freeMatrix(&copyB);

   	fclose(in_file);
	fclose(out_file);

	return 0;

}