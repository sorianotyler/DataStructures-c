//---------------------------------------
// Matrix.c
// Tyler Soriano
// tsoriano@ucsc.edu
// PA2
//---------------------------------------


#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "Matrix.h"

typedef struct EntryObj
{
	int column;
	double value;
} EntryObj;

typedef struct EntryObj* Entry;

typedef struct MatrixObj
{
	int height;
	List rows[];
} MatrixObj;

Entry newEntry(int col, double val)
{
	Entry e = malloc(sizeof(EntryObj)); 	// allocate memory

	e->column = col;						// sets column to integer 

	e->value = val;							// Sets value to the double number 

	return e;								// returns entry
}

// newMatrix()
// Returns a reference to a new nXn Matrix object in the zero state.
Matrix newMatrix(int n)
{
	Matrix m = malloc(sizeof(MatrixObj) + sizeof(List[n]));    // allocate memory

	m->height = n;     										// since its an nxn matrix
	//m->rows[] = rows[n];

	for(int i = 0; i < n; i++)                             // create a list corresponding with every row (how we are going to store entries)
	{
		m->rows[i] = newList();
	}

	return m; 												// return the matrix
}

// freeMatrix()
// Frees heap memory associated with *pM, sets *pM to NULL.
void freeMatrix(Matrix* pM)
{
	if(pM != NULL && *pM != NULL)    			// if the matrix and matrix pointer isnt null
	{
		if(size(*pM) > 0)						// if the size of the matrix is greater than zero
		{
			for(int i = 0; i < (*pM)->height; i++)  // free every list on the matrix
				freeList(&((*pM)->rows[i]));
		}

		free(*pM); // then free the overall matrix
		*pM = NULL; // set the matrix pointer to null
	}
}

// Access functions
// size()
// Return the size of square Matrix M.
int size(Matrix M)
{
	return M->height;     // since it is an nxn matrix the size is just the height(number)^2
}

// NNZ()
// Return the number of non-zero elements in M.
int NNZ(Matrix M)
{
	int i;

	int numNon = 0; 

	for(i = 0; i < M->height; i++)
	{
		numNon += length(M->rows[i]); // since the lists only hold the non zero entries you add the length of each row to a total
	}

	return numNon;
}

// equals()
// Return true (1) if matrices A and B are equal, false (0) otherwise.
int equals(Matrix A, Matrix B)
{
	if( (A->height != B->height) )  // if the size isnt the same -> not true
		return 0;
	else if(NNZ(A) != NNZ(B))       // if the amount of non zero entries are not the same -> not true
 		return 0;

	int i;
	int j;

	for(i = 0; i < A->height; i++)
	{
		moveFront(A->rows[i]);  // move to the front of the list for A 
		moveFront(B->rows[i]);  // move to the front of the list for B

		for(j = 0; j < length(A->rows[i]); j++)  // itterate through and get A and B values 
		{
			void* list_val1 = get(A->rows[i]);   
			void* list_val2 = get(B->rows[i]);

			if(((EntryObj*)list_val1)->value != ((EntryObj*)list_val2)->value) // if values dont match then exit 
				return 0;

			moveNext(A->rows[i]); // move next for A and B
			moveNext(B->rows[i]);
		}
	}


	return 1; // if all the test pass then return 1
}



// Manipulation procedures

// makeZero()
// Re-sets M to the zero Matrix.
void makeZero(Matrix M)
{
	int i;

	for(i = 0; i < M->height; i++)
	{
		if(length(M->rows[i]) != 0)    // itterate through and if there are non zero entries and make them zero
		{
			//printf("%d\n", length(M->rows[i]));
			clear(M->rows[i]);
		}
		//M->rows[i] = newList();
	}
}

// changeEntry()
// Changes the ith row, jth column of M to the value x.
// Pre: 1<=i<=size(M), 1<=j<=size(M)
void changeEntry(Matrix M, int i, int j, double x)
{
	if(i < 1 || i > size(M))  // if the entry column or row is out of range - you cant change it 
		return;

	if(j < 1 || j > size(M))
		return;

	int y;

	moveFront(M->rows[i - 1]); // move to the front of the list 

	for(y = 0; y < NNZ(M); y++)  // itterate through the list 
	{
		void* list_val = get(M->rows[i - 1]);  // get the value 

		if(list_val == NULL)  // if no value -> break
			break;

		int col = ((EntryObj*)list_val)->column;   // cast it to an entry object and get the column number

		if(j > col)
		{
			moveNext(M->rows[i - 1]); // if the columns dont match itterate through
		}
		else if(col == j) //replace here
		{
			if(x == 0)
			{
				delete(M->rows[i - 1]);
			}
			else
				((EntryObj*)list_val)->value = x;

			return;
		}
		else
		{
			if(x != 0)
				insertBefore(M->rows[i - 1], newEntry(j, x));
			return;
		}
	}

	if(index(M->rows[i - 1]) == -1) // if its a new entry - make a new entry
	{
		if(x != 0)
			append(M->rows[i - 1], newEntry(j, x));
	}
	else
	{
		if(x != 0)
			insertAfter(M->rows[i - 1], newEntry(j, x)); // if there is no entry there -> add to end of list 
	}
}



// Matrix Arithmetic operations

// copy()
// Returns a reference to a new Matrix object having the same entries as A
Matrix copy(Matrix A)
{
	Matrix n = newMatrix(A->height);  // copy the size of the matrix

	int curr_index = 0;

	List curr = A->rows[curr_index];  // the current list is according to the row

	moveFront(curr);				// move to the front of the list 

	for(int i = 0; i < NNZ(A); i++)   // itterates untill all of non zero entries are accounted for
	{
		if(index(curr) == -1)  		// if the index is undefined (after we itterate through the list or if there is no entries on list)
		{
			curr = A->rows[++curr_index];  // move to the next row 
			moveFront(curr);

			while(index(curr) == -1)
			{
				curr = A->rows[++curr_index];   // if it is still undefined you keep moving untill it is not undefined
				moveFront(curr);
			}
		}

		//printf("%d\n", curr_index);

		//find out if we want to make shallow copy or deep copy
		//i.e. are we copying references or copying values?

		//making deep copy
		void* list_val = get(curr);   			// getting current value (getting void pointer - not actual data)

		int col    = ((EntryObj*)list_val)->column; // need to cast to an entry object to get both the column # and value double
		double val = ((EntryObj*)list_val)->value; 

		Entry e = newEntry(col, val);				// get new entry 

		append(n->rows[curr_index], e);				// append to appropriate list 

		moveNext(curr);				
	}

	return n;
}

// transpose()
// Returns a reference to a new matrix object representing the transpose
// of A.
Matrix transpose(Matrix A)
{
	Matrix n = newMatrix(A->height);		// create a new matrix

	int curr_index = 0;

	List curr = A->rows[curr_index]; 		

	moveFront(curr);

	int c_count = 1;				// holds column number 

	// for this you want to iterate through until you find all non zero entries 
	for(int i = 0; i < NNZ(A); i++)
	{
		if(index(curr) == -1)   				// if the index is undefined means we made it through the entire list or there are no entries 
		{
			curr = A->rows[++curr_index];  		// go to the next list (row) in the matrix
			c_count++;							// new column now 
			moveFront(curr);					// moves to the front of the new list 

			while(index(curr) == -1)			// if it is still undefined you want to itterate until you get to a non empty list
			{
				curr = A->rows[++curr_index];
				moveFront(curr);

				c_count++;						// with every row you have to increment the column count (colunm number)
			}
		}

		void* list_val = get(curr);				// need to get the current values so you have a void pointer

		int col = ((EntryObj*)list_val)->column;  
		double val = ((EntryObj*)list_val)->value;

		append(n->rows[col - 1], newEntry(c_count, val));

		moveNext(curr);
	}

	return n;
}

// scalarMult()
// Returns a reference to a new object represting xA
Matrix scalarMult(double x, Matrix A)
{
	Matrix n = copy(A);

	int curr_index = 0;

	List curr = n->rows[curr_index];   // get the row

	moveFront(curr);

	for(int i = 0; i < NNZ(n); i++)    // again counting number of non zero elements (only multiplying numbers that are going to be printed)
	{
		if(index(curr) == -1)			// iterate through untill you you find a non empty row 
		{
			curr = n->rows[++curr_index];
			moveFront(curr);

			while(index(curr) == -1)
			{
				curr = n->rows[++curr_index];
				moveFront(curr);
			}
		}

		void* list_val = get(curr); 		// get current element 

		((EntryObj*)list_val)->value *= x;  // multiply it to the given number 

		moveNext(curr);
	}

	return n;
}

// private function for product
double vectorDot(List A, List B)
{
	double result = 0;		

	moveFront(A);			// takes in two list - move to the front of both lists 
	moveFront(B);

	while(index(A) != -1 && index(B) != -1)  		// while both of the cursors on the two lists are defined 
													//(while there are still entries on certain lists)
	{
		void* list_val_a = get(A);					// gettting each value from each of the list 
		void* list_val_b = get(B);
		int col_a = ((EntryObj*)list_val_a)->column; 		// get column number from each of those values 
		int col_b = ((EntryObj*)list_val_b)->column;

		if(col_a == col_b)			// same column - multiply them 
		{
			double val_a = ((EntryObj*)list_val_a)->value;
			double val_b = ((EntryObj*)list_val_b)->value;

			result += val_a * val_b;			// add the value to the result (doing vector multiplication)

			moveNext(A);						// move next
			moveNext(B);
		}
		else if(col_a > col_b)					// if A column is > than B column you move to the next element in B 
			moveNext(B);
		else if(col_a < col_b)					// if B column is > than A column you move to the next element in A 
			moveNext(A);
												// must itterate though and multiply those in the same column 
	}

	return result;
}


// Helper function for addition 
// takes in the list from the coresponding rows - and returns the sum of the two 
List sumRow(List result, List A, List B)
{
	moveFront(A);			// move to the front of both lists 
	moveFront(B);

	while(index(A) != -1 && index(B) != -1)			// they have to be on both lists 
	{
		//printf("%d %d\n", index(A), index(B));

		void* list_val_a = get(A);					// working with columns and values -> have to get the numbers
		void* list_val_b = get(B);
		int col_a = ((EntryObj*)list_val_a)->column;
		int col_b = ((EntryObj*)list_val_b)->column;

		if(col_a == col_b)							// if they have the same column then you add the two (already know they on the same row)
		{
			double val_a = ((EntryObj*)list_val_a)->value;
			double val_b = ((EntryObj*)list_val_b)->value;

			if((val_a + val_b) != 0)
				append(result, newEntry(col_a, val_a + val_b));

			moveNext(A);
			moveNext(B);
		}
		else if(col_a > col_b)					// you move accordingly 
		{
			double val_b = ((EntryObj*)list_val_b)->value;
			append(result, newEntry(col_b, val_b));
			moveNext(B);
		}
		else if(col_a < col_b)
		{
			double val_a = ((EntryObj*)list_val_a)->value;
			append(result, newEntry(col_a, val_a));
			moveNext(A);
		}
	}

	// special cases -> if one list isnt done but the other is then you must add the remainder of either of the lists to the new list 
	// we dont lose anything by adding 0 to a number 
	if(index(A) == -1 && index(B) >= 0)
	{
		while(index(B) != -1)
		{
			void* list_val_b = get(B);
			int col_b = ((EntryObj*)list_val_b)->column;

			double val_b = ((EntryObj*)list_val_b)->value;
			append(result, newEntry(col_b, val_b));
			moveNext(B);
		}
	}
	else if(index(B) == -1 && index(A) >= 0)
	{
		while(index(A) != -1)
		{
			void* list_val_a = get(A);
			int col_a = ((EntryObj*)list_val_a)->column;

			double val_a = ((EntryObj*)list_val_a)->value;
			append(result, newEntry(col_a, val_a));
			moveNext(A);
		}
	}

	return result;
}

//Helper function for addition
// follows the same exact logic for sumRow instead subtracting the values 
List diffRow(List result, List A, List B)
{
	moveFront(A);
	moveFront(B);

	while(index(A) != -1 && index(B) != -1)
	{
		void* list_val_a = get(A);
		void* list_val_b = get(B);
		int col_a = ((EntryObj*)list_val_a)->column;
		int col_b = ((EntryObj*)list_val_b)->column;

		if(col_a == col_b)
		{
			double val_a = ((EntryObj*)list_val_a)->value;
			double val_b = ((EntryObj*)list_val_b)->value;

			if((val_a - val_b) != 0)
				append(result, newEntry(col_a, val_a - val_b));

			moveNext(A);
			moveNext(B);
		}
		else if(col_a > col_b)
		{
			double val_b = 0 - ((EntryObj*)list_val_b)->value;
			append(result, newEntry(col_b, val_b));
			moveNext(B);
		}
		else if(col_a < col_b)
		{
			double val_a = ((EntryObj*)list_val_a)->value;
			append(result, newEntry(col_a, val_a));
			moveNext(A);
		}
	}

	if(index(A) == -1 && index(B) >= 0)
	{
		while(index(B) != -1)
		{
			void* list_val_b = get(B);
			int col_b = ((EntryObj*)list_val_b)->column;

			double val_b = 0 - ((EntryObj*)list_val_b)->value;
			append(result, newEntry(col_b, val_b));
			moveNext(B);
		}
	}
	else if(index(B) == -1 && index(A) >= 0)
	{
		while(index(A) != -1)
		{
			void* list_val_a = get(A);
			int col_a = ((EntryObj*)list_val_a)->column;

			double val_a = ((EntryObj*)list_val_a)->value;
			append(result, newEntry(col_a, val_a));
			moveNext(A);
		}
	}

	return result;
}

// sum()
// Returns a reference to a new object representing A+B.
// pre: size(A)==size(B)
Matrix sum(Matrix A, Matrix B)
{
	if(size(A) != size(B))
		return NULL;

	Matrix n = newMatrix(A->height);
	Matrix C = copy(B); 				// using copy as to not change the actual data 

	for(int i = 0; i < size(A); i++)
	{
		n->rows[i] = sumRow(n->rows[i], A->rows[i], C->rows[i]); 		// using our helper function going the row each of the lists 
	}

	freeMatrix(&C);			// free the C matrix created for memory leak issues

	return n;
}

// diff()
// Returns a reference to a new object representing A-B.
// pre: size(A)==size(B)
Matrix diff(Matrix A, Matrix B)
{
	if(size(A) != size(B))
		return NULL;

	Matrix n = newMatrix(A->height);
	Matrix C = copy(B);

	for(int i = 0; i < size(A); i++)
		n->rows[i] = diffRow(n->rows[i], A->rows[i], C->rows[i]);           // using our helper function going the row each of the lists 

	freeMatrix(&C);

	return n;
}

// product()
// Returns a reference to a new Matrix
// pre: size(A)==size(B)
Matrix product(Matrix A, Matrix B)
{
	if(size(A) != size(B))
		return NULL;

	int i = 0;

	Matrix C = transpose(B);
	Matrix nm = newMatrix(A->height);

	int c_count = 0;

	while(i < A->height)
	{
		//For debugging:
		//printf("%d\n", i);

		int x = 0;

		while(x < B->height)
		{
			double result = vectorDot(A->rows[i], C->rows[x]);  // using our helper function going the row each of the lists 

			++c_count;

			if(result != 0)
				append(nm->rows[i], newEntry(c_count, result));

			x++;
		}

		c_count = 0;
		i++;
	}

	freeMatrix(&C);

	return nm;
}

// printMatrix()
// Prints a string representation of Matrix M to filestream out. Zero rows
// of the row number, followed by a colon, a space, then a space separated
// list of pairs "(col, val)" giving the column numbers and non-zero values
// in that row. The double val will be rounded to 1 decimal point.
void printMatrix(FILE* out, Matrix M)
{
	int i;
	int j;

	for(i = 0; i < M->height; i++)
	{
		if(length(M->rows[i]) == 0)
			continue;

		fprintf(out, "%d: ", i + 1);
		moveFront(M->rows[i]);

		for(j = 0; j < length(M->rows[i]); j++)
		{
			void* list_val = get(M->rows[i]);

			int col = ((EntryObj*)list_val)->column;
			double val = ((EntryObj*)list_val)->value;

			if(val != 0.0)
			{
				fprintf(out, "(%d, %.1lf) ", col, val);
			}

			moveNext(M->rows[i]);
		}

		fprintf(out, "\n");
	}
}
