//-----------------------------------------------------------------------------
//  MatrixClient.c
//  A test client for the Matrix ADT
//-----------------------------------------------------------------------------
#include<stdio.h>
#include<stdlib.h>
#include"Matrix.h"

int main()
{

   int n=10;
   Matrix A = newMatrix(n);
   changeEntry(A, 2, 1, 2);
    changeEntry(A, 3, 1, 5);
    changeEntry(A, 1, 2, 2);
    changeEntry(A, 1, 3, 5);
    changeEntry(A, 1, 1, 4);
    changeEntry(A, 2, 2, 2);
    changeEntry(A, 2, 5, 0);
    changeEntry(A, 2, 3, 0);
    changeEntry(A, 3, 3, 5);
    printf("%d\n", NNZ(A));
    changeEntry(A, 1, 3, 0);
    changeEntry(A, 3, 1, 0);
    changeEntry(A, 3, 3, 0);
    printf("%d\n", NNZ(A));
    changeEntry(A, 7, 6, 42);
    changeEntry(A, 10, 1, 24);
    printf("%d\n", NNZ(A));
    changeEntry(A, 7, 6, 0);
    printf("%d\n", NNZ(A));
    printMatrix(stdout, A);
    makeZero(A);
    changeEntry(A, 5, 5, 5);
    printf("%d\n", NNZ(A));
    return 0;


   return EXIT_SUCCESS;
}
